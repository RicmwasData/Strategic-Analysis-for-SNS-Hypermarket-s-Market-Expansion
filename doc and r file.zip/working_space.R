# load libraries
library(tidyverse)
library(psych)
library(Hmisc) 

#read the data into r 
#read the data from the current working directory 
Superstore<- read_csv("./Superstore.Latifa.csv",
                      col_types = cols(Sales= col_double(),
                                       Quantity= col_double(),
                                       Discount=col_double(),
                                       Profit= col_double()))

#quick overview of the data record
head(Superstore)

#overview and data structure
glimpse(Superstore)

#summary statistics 
summary(Superstore)

#3. 
#divide the data into regions 
#check the unique regions in the data 
unique(Superstore$Region)

South<- subset(Superstore, Region=="South")
West<- subset(Superstore, Region=="West")
East<- subset(Superstore, Region=="East")
Central<- subset(Superstore, Region=="Central")

#Decriptive 
describe(South[,9:12])[c(3,4,8,9)]
describe(West[,9:12])[c(3,4,8,9)]
describe(East[,9:12])[c(3,4,8,9)]
describe(Central[,9:12])[c(3,4,8,9)]


#3. 
#log transformation 
Superstore$Sales<- log(Superstore$Sales)

# Normalize 'Quantity'
Superstore$Quantity <- (Superstore$Quantity - min(Superstore$Quantity, na.rm = T)) /
  (max(Superstore$Quantity, na.rm = T) - min(Superstore$Quantity, na.rm = T))

#4. 
#impute missing values 
Superstore$Sales<- impute(Superstore$Sales, mean)
Superstore$Quantity<- impute(Superstore$Quantity, mean)
Superstore$Discount<- impute(Superstore$Discount,mean)
Superstore$Profit<- impute(Superstore$Profit,mean)
#Data summary
summary(Superstore)

#validate the data
invalid_indices <- which(Superstore$Discount < 0 | Superstore$Discount > 1)
invalid_indices
Superstore$Discount[invalid_indices] <- median(Superstore$Discount, na.rm = TRUE)

#5. 
# Sales Distribution by Segment
ggplot(Superstore, aes(x=Segment, y=Sales)) +
  geom_boxplot() +
  labs(title="Sales Distribution by Segment", x="Segment", y="Sales")

#Sales vs Profit by Region
ggplot(Superstore, aes(x=Sales, y=Profit, color=Region)) +
  geom_point() +
  labs(title="Sales vs Profit by Region", x="Sales", y="Profit")


#6. 
#average by region
Superstore%>%
  group_by(Region)%>%
  summarise(mean_profit= mean(Profit))

#correlation martrix
cormat<-cor(Superstore[,9:12])
corPlot(cormat, cex = 1)

#7, 
#linear regression 
m1<- lm(Profit~ Sales+Quantity+Discount,
        data = Superstore)
summary(m1)

# Logistic regression 
# Load necessary libraries
library(caret)

Superstore<- Superstore[,9:12]
# Convert Profit to a binary variable
Superstore$Profit <- ifelse(Superstore$Profit > 0, 1, 0)

# Partition the data into training and testing sets
set.seed(123)  # for reproducibility
trainIndex <- createDataPartition(Superstore$Profit, p = 0.8, list = FALSE)
trainSet <- Superstore[trainIndex, ]
testSet <- Superstore[-trainIndex, ]

# Build the model on the training set
model <- glm(Profit ~ Sales + Quantity + Discount, data = trainSet, family = binomial)

# Make predictions on the testing set
predictions <- predict(model, newdata = testSet, type = "response")
predictions <- ifelse(predictions > 0.5, 1, 0)

# Create a confusion matrix
confusionMatrix(as.factor(predictions), as.factor(testSet$Profit))

